library('raster')
library('rgdal')
library('plotrix')
library('fields')

stable <- readOGR(dsn="C:/RICERCA/CIAS_CORRELATION-IMAGE-ANALYSIS/calita_b04", layer= "Muraglione_stable")  
calita_perimeter <- readOGR(dsn="C:/RICERCA/calita", layer= "calita_perimeter")
GPS_perm <- readOGR(dsn="C:/RICERCA/calita", layer = "rover_calita_utm32")
# plot(calita_perimeter)
# points(GPS_perm,pch=19,col='blue')

basemap <- raster("C:/RICERCA/CIAS_CORRELATION-IMAGE-ANALYSIS/calita_b04/da_processare/T32TPQ_A008528_20181024T102428_B04.jp2")
calita_square <- readOGR(dsn="C:/RICERCA/CIAS_CORRELATION-IMAGE-ANALYSIS/calita_b04", layer ='CL_outline_square')
basemap <- crop(basemap,calita_square)
# base_stack <- raster::stack(rep("C:/RICERCA/CIAS_CORRELATION-IMAGE-ANALYSIS/calita_b04/da_processare/T32TPQ_A008528_20181024T102428_B04.jp2",4))
# base_stack <- crop(base_stack,calita_square)
# r_stack <- 
# plot(base_stack)

folders <- list.dirs(full.names = F)
folders <-  folders[grep('_20',folders)]
  folders <- folders[-grep('/',folders)]; folders <- folders[c(1:9,11,13,15,17:20,22,25,27,29,31,33,36,40,42,44,48,51,54,57,60,63:73,75:77,79,81:84)]

dates <- vector(length = length(folders)+1)

i=4

for (i in 1 : length(folders) ){
  dates [i] <- paste0(substr(folders[i],start = 1,stop = 4),'/',
                      substr(folders[i],start = 5,stop = 6),'/',
                      substr(folders[i],start = 7,stop = 8)
  )
  
}
dates[i+1] <- paste0(substr(folders[i],start = 1+9,stop = 4+9),'/',
                     substr(folders[i],start = 5+9,stop = 6+9),'/',
                     substr(folders[i],start = 7+9,stop = 8+9)
)
dates <- as.Date(dates)

disp <- data.frame(matrix(ncol = 5, nrow = length(dates))); colnames(disp) <- c("Date",rev(as.character(GPS_perm$Punto)),'delta_T')
disp$Date <- dates
disp$delta_T[2:nrow(disp)] <- diff(disp$Date)

disp[1,2:4] <- rep(0,3)

pal <- colorRampPalette(c("green",'yellow',"red"),alpha = .4)
corr_th <- 0
  



pdf(file = "C:/RICERCA/CIAS_CORRELATION-IMAGE-ANALYSIS/calita_b04/r_result/r_output_rev_stable.pdf ",paper = "a4r")
 par(mfrow= c(2,3),mar = c(3,4,2,3),pty="m",new=F)
# layout(matrix(rbind(c(1,1,1),c(2,3,4)),2,3))
 i =2
 
for (i in 1:length(folders)) {
 # for (i in 1:4) {
  print(i)
data <- (read.csv(paste0(folders[i],"/NCC_10_15_10.txt")))
data_50 <- (read.csv(paste0(folders[i],"/NCC_10_15_50.txt")))
colnames(data)[5] <- "displ"

data_coer <- dplyr::filter(data, max_corrcoeff >= corr_th )
data_coer_50 <- dplyr::filter(data_50, max_corrcoeff >= corr_th )

z_max <- 60

  r_50 <- rasterFromXYZ(data_coer_50); crs(r_50) <- CRS("+init=epsg:32632")
# r_50 <- mask(r_50,calita_perimeter[2:4,])
# r_50 <- rasterToPolygons(r_50)
r_50$X <- coordinates(r_50)[,1]
r_50$Y <- coordinates(r_50)[,2]

r <- rasterFromXYZ(data_coer)
crs(r) <- CRS("+init=epsg:32632")
# r <- mask(r,calita_perimeter[2:4,])
r <- mask(r,stable)
colori <- colorRampPalette(c('green','yellow','red'))
# q_98 <- quantile(mask(r$displ,calita_perimeter[which(calita_perimeter$Id == 1),]),probs = 0.98)
q_99 <- quantile(r_50$length,probs = 0.99)
    
    while(q_99 < 10) {
    q_99 <- 10
    }

par(mfrow = c(2,3))
plot(r$displ,col = pal(20),
     # zlim= c(0,q_99),
     zlim= c(0,z_max),
     main =paste0(folders[i]," - ","Max corr. thres.=",corr_th),
     legend.args=list(text='Displ. (m)', side=4, font=1, line=2, cex=0.8),as)
 lines(calita_perimeter[2:4,],col="red",lwd=2)

 as.data.frame(r_50[r_50$length > 7 & r_50$max_corrcoeff > 0.7 ]) -> frecce
 # as.data.frame(r_50[r_50$length > 7 & r_50$max_corrcoeff > 0.7 & r_50$direction > 45 & r_50$direction < 180,]) ->frecce
as.data.frame(r_50[r_50$length <= 7 &  r_50$max_corrcoeff > 0.7,]) ->punti

# ifelse(test =nrow(frecce) > 0,
#        yes = fields::arrow.plot(a1 = frecce$X,a2 = frecce$Y, frecce$dx,frecce$dy,arrow.ex = .1,length=.05, lwd=1),
#        no= print("fermo")
# )
# 
# ifelse(test =nrow(frecce) > 0,
#        yes = fields::arrow.plot(a1 = frecce$X,a2 = frecce$Y, frecce$dx,frecce$dy,arrow.ex = .1,length=.05, lwd=1),
#        no= print("fermo")
# )
r_50_piana <- mask(r_50,calita_perimeter[3,])
r_50_colata_A <- mask(r_50,calita_perimeter[2,])
r_50_colata_B <- mask(r_50,calita_perimeter[4,])

# scala_max <- max(c(ceiling(summary(r_50_piana[r_50_piana$max_corrcoeff > .7][,3])[6]),
#                    ceiling(summary(r_50_colata_A[r_50_colata_A$max_corrcoeff > .7][,3])[6]),
#                    ceiling(summary(r_50_colata_B[r_50_colata_B$max_corrcoeff > .7][,3])[6])
#                  )
#                   )
scala_max <- 50

r_50_df <- as.data.frame(r_50[r_50$max_corrcoeff > .7,])
polar.plot( (r_50_df$length),(r_50_df$direction),label.prop=1.15,
            # radial.lim = c(0,ceiling(summary(r_50_df$length)[6])),
            radial.lim = c(0,scala_max),
            start=90,clockwise=TRUE,lwd=3,line.col='black',boxed.radial=F,grid.col='grey',grid.unit='(m)')

# r_50 <- as.data.frame(r_50[r_50$max_corrcoeff > .7,])





# 
# ggplot() + layer_spatial(r$displ) +scale_fill_gradientn(colours =colori(10)  , name = "Displ. m") +
#   labs(title = paste0(folders[i]," - ","Max corr. thres.=",corr_th)) +
#   layer_spatial(calita_perimeter[2:4,],col =c('black','blue','red'),alpha=0) -> g_plot


# 
# # layout.matrix <- rbind(c(1,1,1),c(2,3,4))
#  # layout(mat = layout.matrix)
# # layout.show(4)
# plot.new();plot.new()
plot.new()
polar.plot(r_50_piana[r_50_piana$max_corrcoeff > .7][,3],#length
           r_50_piana[r_50_piana$max_corrcoeff > .7][,4],#azimuth
           label.prop=1.15,
           radial.lim = c(0,scala_max),
           start=90,clockwise=TRUE,lwd=3,line.col='black',boxed.radial=F,grid.col='grey',grid.unit='(m)',main ="Source zone")

par(new=T);polar.plot(mean(r_50_piana[r_50_piana$max_corrcoeff > .7][,3],na.rm =T),#length
                      median(r_50_piana[r_50_piana$max_corrcoeff > .7][,4],na.rm =T),#azimuth
           label.prop=1.15,
           radial.lim = c(0,scala_max),
           start=90,clockwise=TRUE,lwd=3,line.col='red',boxed.radial=F,grid.col='grey',grid.unit='(m)',main ="Source zone")


polar.plot(r_50_colata_A[r_50_colata_A$max_corrcoeff > .7][,3],#length
           r_50_colata_A[r_50_colata_A$max_corrcoeff > .7][,4],#azimuth
           label.prop=1.15,
           radial.lim = c(0,scala_max),
           start=90,clockwise=TRUE,lwd=3,line.col='black',boxed.radial=F,grid.col='grey',grid.unit='(m)',main="Up earth flow/slide")
par(new=T);polar.plot(mean(r_50_colata_A[r_50_colata_A$max_corrcoeff > .7][,3],na.rm = T),#length
                      median(r_50_colata_A[r_50_colata_A$max_corrcoeff > .7][,4],na.rm = T),#azimuth
                      label.prop=1.15,
                      radial.lim = c(0,scala_max),
                      start=90,clockwise=TRUE,lwd=3,line.col='red',boxed.radial=F,grid.col='grey')


polar.plot(r_50_colata_B[r_50_colata_B$max_corrcoeff > .7][,3],#length
           r_50_colata_B[r_50_colata_B$max_corrcoeff > .7][,4],#azimuth
           label.prop=1.15,
           radial.lim = c(0,scala_max),
           start=90,clockwise=TRUE,lwd=3,line.col='black',boxed.radial=F,grid.col='grey',grid.unit='(m)',main="Low earth flow/slide")
par(new=T);polar.plot(mean(r_50_colata_B[r_50_colata_B$max_corrcoeff > .7][,3],na.rm = T),#length
           median(r_50_colata_B[r_50_colata_B$max_corrcoeff > .7][,4],na.rm = T),#azimuth
           label.prop=1.15,
           radial.lim = c(0,scala_max),
           start=90,clockwise=TRUE,lwd=3,line.col='red',boxed.radial=F,grid.col='grey',grid.unit='(m)',main="Low earth flow/slide")

title(main  =  folders[i],outer = T,line = -2)

# plot(r_50$length,col = pal(20),
 #     # zlim= c(0,z_max),
 #     zlim= c(0,q_99),
 #     main =paste0(folders[i]," - ","Max corr. thres.=",corr_th),
 #     legend.args=list(text='Displ. (m)', side=4, font=1, line=2, cex=0.8))

 #  points(punti$X,punti$Y,cex=.1)
 # # arrows(x0 = a$X,y0 =  a$Y,x1 =a$X + a$dx,y1 = a$Y + a$dy,code = 1,col = 'red')
 
  # polar.plot( frecce$length,frecce$direction,label.prop=1.15,
  #            radial.lim = c(0,ceiling(summary(frecce$length)[5])),
  #            start=90,clockwise=TRUE,lwd=3,line.col='black',boxed.radial=F,grid.col='grey',grid.unit='(m)')
  # 
   # mtext(side=1,line=1,cex=.7,
        # text=paste0('d-Az=',abs(GPS$Azimuth[select[i]]-OT$Azimuth[OT_call[i]]),'? - d-Module=',round(abs(GPS$length[select[i]]-OT$length[OT_call[i]]),2),'m' ))
  
  #   par(new=T)
  #   par(cex.axis=0.7)
  #   par(cex.lab=0.2)
  # polar.plot(OT$length[OT_call[i]],OT$Azimuth[OT_call[i]],radial.lim=c(0,max(GPS$length[select[i]])+max(GPS$length[select[i]])*0.5),
             # start=90,clockwise=TRUE,lwd=3,line.col='red',boxed.radial=F,xlab='meters',add=T)
}
dev.off()

par(mfrow = c(3,4),pty='m',mar = c(2,2,2,3))
pdf(file = "C:/RICERCA/CIAS_CORRELATION-IMAGE-ANALYSIS/calita_b04/r_result/r_output_map_stable.pdf ",paper = "a4r")
# par(mfrow= c(2,3),mar = c(3,4,2,3),pty="m",new=F)
# layout(matrix(rbind(c(1,1,1),c(2,3,4)),2,3))
# i =2
i=1
for (i in 1:length(folders)) {
  # for (i in 1:4) {
  print(i)
  data <- (read.csv(paste0(folders[i],"/NCC_10_15_10.txt")))
  data_50 <- (read.csv(paste0(folders[i],"/NCC_10_15_50.txt")))
  colnames(data)[5] <- "displ"
  
  data_coer <- dplyr::filter(data, max_corrcoeff >= corr_th )
  data_coer_50 <- dplyr::filter(data_50, max_corrcoeff >= corr_th )
  
  z_max <- 60
  
  r_50 <- rasterFromXYZ(data_coer_50); crs(r_50) <- CRS("+init=epsg:32632")
  r_50 <- mask(r_50,calita_perimeter[2:4,])
  # r_50 <- rasterToPolygons(r_50)
  r_50$X <- coordinates(r_50)[,1]
  r_50$Y <- coordinates(r_50)[,2]
  
  r <- rasterFromXYZ(data_coer)
  crs(r) <- CRS("+init=epsg:32632")
  # r <- mask(r,calita_perimeter[2:4,])
  r <- mask(r,stable)
  colori <- colorRampPalette(c('green','yellow','red'))
  # q_98 <- quantile(mask(r$displ,calita_perimeter[which(calita_perimeter$Id == 1),]),probs = 0.98)
  q_99 <- quantile(r_50$length,probs = 0.99)
  
  while(q_99 < 10) {
    q_99 <- 10
  }
  
  
  plot(basemap,col = gray.colors(200, start = 0, end = 1, gamma = 2.2),
       main =paste0(folders[i]," - ","Max corr. thres.=",corr_th),
       legend= F)
  lines(calita_perimeter[2:4,],col="red",lwd=1)
  plot(r$displ,col = pal(20),alpha=0.35,
       # zlim= c(0,q_99),
       zlim= c(0,z_max),
       legend=F,add=T)
  plot(r$displ,col = pal(20),
       legend.only=T,
       legend.args=list(text='Displ. (m)',alpha=NULL,  side=4, font=1, line=2, cex=0.8),
       zlim= c(0,z_max))
  
  
  as.data.frame(r_50[r_50$length > 7 & r_50$max_corrcoeff > 0.7 ]) -> frecce
  # as.data.frame(r_50[r_50$length > 7 & r_50$max_corrcoeff > 0.7 & r_50$direction > 45 & r_50$direction < 180,]) ->frecce
  as.data.frame(r_50[r_50$length <= 7 &  r_50$max_corrcoeff > 0.7,]) ->punti
  
  # ifelse(test =nrow(frecce) > 0,
  #        yes = fields::arrow.plot(a1 = frecce$X,a2 = frecce$Y, frecce$dx,frecce$dy,arrow.ex = .1,length=.05, lwd=1),
  #        no= print("fermo")
  # )

  # ifelse(test =nrow(frecce) > 0,
  #        yes = fields::arrow.plot(a1 = frecce$X,a2 = frecce$Y, frecce$dx,frecce$dy,arrow.ex = .1,length=.05, lwd=1),
  #        no= print("fermo")
  # )
  # r_50_piana <- mask(r_50,calita_perimeter[3,])
  # r_50_colata_A <- mask(r_50,calita_perimeter[2,])
  # r_50_colata_B <- mask(r_50,calita_perimeter[4,])
  # 
  # # scala_max <- max(c(ceiling(summary(r_50_piana[r_50_piana$max_corrcoeff > .7][,3])[6]),
  # #                    ceiling(summary(r_50_colata_A[r_50_colata_A$max_corrcoeff > .7][,3])[6]),
  # #                    ceiling(summary(r_50_colata_B[r_50_colata_B$max_corrcoeff > .7][,3])[6])
  # #                  )
  # #                   )
  # scala_max <- 50
  # 
  # r_50_df <- as.data.frame(r_50[r_50$max_corrcoeff > .7,])
  # polar.plot( (r_50_df$length),(r_50_df$direction),label.prop=1.15,
  #             # radial.lim = c(0,ceiling(summary(r_50_df$length)[6])),
  #             radial.lim = c(0,scala_max),
  #             start=90,clockwise=TRUE,lwd=3,line.col='black',boxed.radial=F,grid.col='grey',grid.unit='(m)')
  # 
  # # r_50 <- as.data.frame(r_50[r_50$max_corrcoeff > .7,])
  # 
  # 
  # 
  # 
  # 
  # # 
  # # ggplot() + layer_spatial(r$displ) +scale_fill_gradientn(colours =colori(10)  , name = "Displ. m") +
  # #   labs(title = paste0(folders[i]," - ","Max corr. thres.=",corr_th)) +
  # #   layer_spatial(calita_perimeter[2:4,],col =c('black','blue','red'),alpha=0) -> g_plot
  # 
  # 
  # # 
  # # # layout.matrix <- rbind(c(1,1,1),c(2,3,4))
  # #  # layout(mat = layout.matrix)
  # # # layout.show(4)
  # # plot.new();plot.new()
  # plot.new()
  # polar.plot(r_50_piana[r_50_piana$max_corrcoeff > .7][,3],#length
  #            r_50_piana[r_50_piana$max_corrcoeff > .7][,4],#azimuth
  #            label.prop=1.15,
  #            radial.lim = c(0,scala_max),
  #            start=90,clockwise=TRUE,lwd=3,line.col='black',boxed.radial=F,grid.col='grey',grid.unit='(m)',main ="Source zone")
  # 
  # par(new=T);polar.plot(mean(r_50_piana[r_50_piana$max_corrcoeff > .7][,3],na.rm =T),#length
  #                       median(r_50_piana[r_50_piana$max_corrcoeff > .7][,4],na.rm =T),#azimuth
  #                       label.prop=1.15,
  #                       radial.lim = c(0,scala_max),
  #                       start=90,clockwise=TRUE,lwd=3,line.col='red',boxed.radial=F,grid.col='grey',grid.unit='(m)',main ="Source zone")
  # 
  # 
  # polar.plot(r_50_colata_A[r_50_colata_A$max_corrcoeff > .7][,3],#length
  #            r_50_colata_A[r_50_colata_A$max_corrcoeff > .7][,4],#azimuth
  #            label.prop=1.15,
  #            radial.lim = c(0,scala_max),
  #            start=90,clockwise=TRUE,lwd=3,line.col='black',boxed.radial=F,grid.col='grey',grid.unit='(m)',main="Up earth flow/slide")
  # par(new=T);polar.plot(mean(r_50_colata_A[r_50_colata_A$max_corrcoeff > .7][,3],na.rm = T),#length
  #                       median(r_50_colata_A[r_50_colata_A$max_corrcoeff > .7][,4],na.rm = T),#azimuth
  #                       label.prop=1.15,
  #                       radial.lim = c(0,scala_max),
  #                       start=90,clockwise=TRUE,lwd=3,line.col='red',boxed.radial=F,grid.col='grey')
  # 
  # 
  # polar.plot(r_50_colata_B[r_50_colata_B$max_corrcoeff > .7][,3],#length
  #            r_50_colata_B[r_50_colata_B$max_corrcoeff > .7][,4],#azimuth
  #            label.prop=1.15,
  #            radial.lim = c(0,scala_max),
  #            start=90,clockwise=TRUE,lwd=3,line.col='black',boxed.radial=F,grid.col='grey',grid.unit='(m)',main="Low earth flow/slide")
  # par(new=T);polar.plot(mean(r_50_colata_B[r_50_colata_B$max_corrcoeff > .7][,3],na.rm = T),#length
  #                       median(r_50_colata_B[r_50_colata_B$max_corrcoeff > .7][,4],na.rm = T),#azimuth
  #                       label.prop=1.15,
  #                       radial.lim = c(0,scala_max),
  #                       start=90,clockwise=TRUE,lwd=3,line.col='red',boxed.radial=F,grid.col='grey',grid.unit='(m)',main="Low earth flow/slide")
  # 
  # title(main  =  folders[i],outer = T,line = -2)
  
  # plot(r_50$length,col = pal(20),
  #     # zlim= c(0,z_max),
  #     zlim= c(0,q_99),
  #     main =paste0(folders[i]," - ","Max corr. thres.=",corr_th),
  #     legend.args=list(text='Displ. (m)', side=4, font=1, line=2, cex=0.8))
  
  #  points(punti$X,punti$Y,cex=.1)
  # # arrows(x0 = a$X,y0 =  a$Y,x1 =a$X + a$dx,y1 = a$Y + a$dy,code = 1,col = 'red')
  
  # polar.plot( frecce$length,frecce$direction,label.prop=1.15,
  #            radial.lim = c(0,ceiling(summary(frecce$length)[5])),
  #            start=90,clockwise=TRUE,lwd=3,line.col='black',boxed.radial=F,grid.col='grey',grid.unit='(m)')
  # 
  # mtext(side=1,line=1,cex=.7,
  # text=paste0('d-Az=',abs(GPS$Azimuth[select[i]]-OT$Azimuth[OT_call[i]]),'? - d-Module=',round(abs(GPS$length[select[i]]-OT$length[OT_call[i]]),2),'m' ))
  
  #   par(new=T)
  #   par(cex.axis=0.7)
  #   par(cex.lab=0.2)
  # polar.plot(OT$length[OT_call[i]],OT$Azimuth[OT_call[i]],radial.lim=c(0,max(GPS$length[select[i]])+max(GPS$length[select[i]])*0.5),
  # start=90,clockwise=TRUE,lwd=3,line.col='red',boxed.radial=F,xlab='meters',add=T)
}
dev.off()
# ### GPS###
# points(GPS_perm,pch=12)
 # text(coordinates(GPS_perm)+100, labels = GPS_perm$Punto)
# 
# dplyr::filter(data_coer,data_coer$X < as.numeric(GPS_perm$Lat[1]+30) & data_coer$X > as.numeric(GPS_perm$Lat[1]-30) & data_coer$Y < as.numeric(GPS_perm$Long[1]+30) & data_coer$Y > as.numeric(GPS_perm$Long[1]-30)) %>% select(displ,max_corrcoeff) -> disp_ROV3
# ifelse(round(median(disp_ROV3$displ,na.rm = T),1) <= 4,
#        0 -> disp$ROV3[i+1],
#        round(median(disp_ROV3$displ,na.rm = T),1) -> disp$ROV3[i+1])
#        
# 
# dplyr::filter(data_coer,data_coer$X < as.numeric(GPS_perm$Lat[2]+30) & data_coer$X > as.numeric(GPS_perm$Lat[2]-30) & data_coer$Y < as.numeric(GPS_perm$Long[2]+30) & data_coer$Y > as.numeric(GPS_perm$Long[2]-30)) %>% select(displ,max_corrcoeff) -> disp_ROV2
# ifelse(round(median(disp_ROV2$displ,na.rm = T),1) <= 4,
#        0 -> disp$ROV2[i+1],
#        round(median(disp_ROV2$displ,na.rm = T),1) -> disp$ROV2[i+1])
# 
# dplyr::filter(data_coer,data_coer$X < as.numeric(GPS_perm$Lat[3]+30) & data_coer$X > as.numeric(GPS_perm$Lat[3]-30) & data_coer$Y < as.numeric(GPS_perm$Long[3]+30) & data_coer$Y > as.numeric(GPS_perm$Long[3]-30)) %>% select(displ,max_corrcoeff) -> disp_ROV1
# ifelse(round(median(disp_ROV1$displ,na.rm = T),1) <= 3,
#        0 -> disp$ROV1[i+1],
#        round(median(disp_ROV1$displ,na.rm = T),1) -> disp$ROV1[i+1]) 

# writeRaster(r,filename = paste0("C:\\RICERCA/CIAS_CORRELATION-IMAGE-ANALYSIS/calita_b04/output/",folders[i],'.tif'),format = "GTiff")

# hist(r$displ,breaks= 200, col='blue') 

# 
#  dplyr::filter(data,X < (GPS_coor$x[1]+30) & X > (GPS_coor$x[1]-30) & Y < (GPS_coor$Y[1]+30) & Y > (GPS_coor$Y[1]-30)) %>% select(length,max_corrcoeff) -> displ_GPS_3
# median(displ_GPS_3$length)
# 
# a <- raster('20170308_20170414/dis_20170308_20170414.tif')
# pal <- colorRampPalette(c("green",'yellow',"red"))
# pal_cor <- colorRampPalette(c("red","white",'blue'))

# par(mfrow = c(1,1))
# plot(a,col = pal(70),zlim=c(0,100))
# plot(raster("20170308_20170414/maxcorr_20170308_20170414.tif"),zlim= c(-1,1),
#      col= pal_cor(10))
# hist(a)

# 
# m <- matrix(nrow = 200, ncol = 200, 0)
# m[10:15,10:15] <- 1
# 
# m2 <- matrix(nrow = 200, ncol = 200, 0)
# m2[10:15,15:20] <- 1
# 
# par(mfrow = c(1,2))
# plot(raster(m))
# plot(raster(m2))


# get( getOption( "device" ) )()
# 
# ##  Split the screen into two rows and one column, defining screens 1 and 2.
# 
# split.screen( figs = c( 2, 1 ) )
# 
# ##  Split screen 1 into one row and three columns, defining screens 3, 4, and 5.
# 
# split.screen( figs = c( 1, 3 ), screen = 1 )
# 
# ##  Split screen 2 into one row and two columns, defining screens 6 and 7.
# 
# split.screen( figs = c( 1, 1 ), screen = 2 )
# 
# ##  The first plot is located in screen 3:
# 
# screen( 3 )
# polar.plot(r_50_piana[r_50_piana$max_corrcoeff > .7][,3],#length
#            r_50_piana[r_50_piana$max_corrcoeff > .7][,4],#azimuth
#            label.prop=1.15,
#            radial.lim = c(0,scala_max),
#            start=90,clockwise=TRUE,lwd=3,line.col='black',boxed.radial=F,grid.col='grey',grid.unit='(m)',main ="Source zone") -> Source_z
# screen( 4 )
# polar.plot(r_50_colata_A[r_50_colata_A$max_corrcoeff > .7][,3],#length
#            r_50_colata_A[r_50_colata_A$max_corrcoeff > .7][,4],#azimuth
#            label.prop=1.15,
#            radial.lim = c(0,scala_max),
#            start=90,clockwise=TRUE,lwd=3,line.col='black',boxed.radial=F,grid.col='grey',grid.unit='(m)',main="Up earth flow/slide") -> colata_A
# screen( 5 )
# polar.plot(r_50_colata_B[r_50_colata_B$max_corrcoeff > .7][,3],#length
#            r_50_colata_B[r_50_colata_B$max_corrcoeff > .7][,4],#azimuth
#            label.prop=1.15,
#            radial.lim = c(0,scala_max),
#            start=90,clockwise=TRUE,lwd=3,line.col='black',boxed.radial=F,grid.col='grey',grid.unit='(m)',main="Low earth flow/slide") -> colata_B
# ##  The second plot is located in screen 4:
# 
# ##  The third plot is located in screen 5:
# 
# 
# ##  The fourth plot is located in screen 6:
# 
# screen( 6 )
# plot(r$displ,col = pal(10),
#      zlim= c(0,q_99),
#      # zlim= c(0,z_max),
#      main =paste0(folders[i]," - ","Max corr. thres.=",corr_th),
#      legend.args=list(text='Displ. (m)', side=4, font=1, line=2, cex=0.8))
# # lines(calita_perimeter,col="red",lwd=2)
# 
# as.data.frame(r_50[r_50$length > 7 & r_50$max_corrcoeff > 0.7 & r_50$direction > 45 & r_50$direction < 270,]) ->frecce
# as.data.frame(r_50[r_50$length <= 7 &  r_50$max_corrcoeff > 0.7,]) ->punti
# 
# # ifelse(test =nrow(frecce) > 0,
# #        yes = fields::arrow.plot(a1 = frecce$X,a2 = frecce$Y, frecce$dx,frecce$dy,arrow.ex = .1,length=.05, lwd=1),
# #        no= print("fermo")
# # )
# 
# ##  The fifth plot is located in screen 7:
# 
# 
# ##  Close all screens.
# 
# close.screen( all = TRUE )
# }