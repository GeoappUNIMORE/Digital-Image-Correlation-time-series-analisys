library("dplyr")
library('raster')
library('rgdal')
library('plotrix')
library('dplyr')
library(ggthemes) # Load
library(ggplot2)
library(ggpmisc)
library(blandr
        )

#04_result_analisys SENTINEL
load("/RICERCA/CIAS_CORRELATION-IMAGE-ANALYSIS/calita_b04/r/03_ts_spostamento/03_ts_spostamento")


# load("V:/GIS-Globale-WMS/Ca_Lita_GIS/CL_GPS-Permanente/2016_marzo_dati_calita1/CL1_2016_export_from_SySanywhere")
# CL_ROV1 -> CL_ROV1_SysAny
# CL_ROV2 -> CL_ROV2_SysAny
# CL_ROV3 -> CL_ROV3_SysAny

# load("T:/calita/Rover_piana/rover_soluzioni_gps_84_df")
# hourly$Hourly <- hourly$Hourly+3600
# hourly %>%  dplyr::filter(Hourly <= as.POSIXct(max(ROV1$dates))) -> hourly
# save(hourly, file= "/RICERCA/CIAS_CORRELATION-IMAGE-ANALYSIS/calita_b04/GPS_data/ROV3_cias")
load("/RICERCA/CIAS_CORRELATION-IMAGE-ANALYSIS/calita_b04/GPS_data/ROV3_cias")



# load("T:/calita/GPS_LEICA/export_GPS_LEICA")
#  CL_ROV1 <- CL_ROV3; rm(CL_ROV3); CL_ROV1$Data  <- CL_ROV1$Data #+ 2*3600
#  CL_ROV1 %>% dplyr::filter(Data <= as.POSIXct(max(ROV1$dates))) -> CL_ROV1
#  save(CL_ROV1, file= "/RICERCA/CIAS_CORRELATION-IMAGE-ANALYSIS/calita_b04/GPS_data/ROV1_cias")
#  CL_ROV2$Data  <- CL_ROV2$Data #+ 2*3600
#  CL_ROV2 %>% dplyr::filter(Data <= as.POSIXct(max(ROV2$dates))) -> CL_ROV2
#  save(CL_ROV2, file= "/RICERCA/CIAS_CORRELATION-IMAGE-ANALYSIS/calita_b04/GPS_data/ROV2_cias")



load("/RICERCA/CIAS_CORRELATION-IMAGE-ANALYSIS/calita_b04/GPS_data/ROV1_cias")
load("/RICERCA/CIAS_CORRELATION-IMAGE-ANALYSIS/calita_b04/GPS_data/ROV2_cias")


# CL_ROV1 <- CL_ROV1[-which(CL_ROV1$ID_Sensore == 103),]

CL_ROV1 <- CL_ROV1[-which(CL_ROV1$BaseLine >= 3000),]
CL_ROV1 <- CL_ROV1[-which(CL_ROV1$Visualizza == F),]
# CL_ROV1_OK_32 <- CL_ROV1[-which(CL_ROV1$E == 0),]
CL_ROV1_OK_32 <- CL_ROV1
coordinates(CL_ROV1_OK_32) <- ~ E + N
proj4string(CL_ROV1_OK_32) <-CRS("+proj=utm +zone=32 ellps=WGS84")
Easting_index <- seq(1,length(coordinates(CL_ROV1_OK_32))/2,1)
Northing_index <-seq(length(coordinates(CL_ROV1_OK_32  ))/2+1,length(coordinates(CL_ROV1_OK_32)),1)
CL_ROV1_OK_32$Northing <- coordinates(CL_ROV1_OK_32)[Northing_index]
CL_ROV1_OK_32$Easting <- coordinates(CL_ROV1_OK_32)[Easting_index]

# ROV1_diff_solution_h      <- sqrt((CL_ROV1_OK_32$Easting-mean(CL_ROV1_OK_32$Easting[1:24],na.rm = T))^2
                                  # +(CL_ROV1_OK_32$Northing-mean(CL_ROV1_OK_32$Northing[1:24],na.rm = T))^2) 

# CL_ROV1_OK_84 <- spTransform(CL_ROV1_OK_32,CRS("+init=epsg:4326"))

CL_ROV2$Data  <- CL_ROV2$Data #+ 2*3600

# CL_ROV2_OK_32 <- CL_ROV2[-which(CL_ROV2$E == 0),]; 
CL_ROV2_OK_32 <- CL_ROV2
# CL_ROV2_OK_32 <- CL_ROV2_OK_32[-which(CL_ROV2_OK_32$ID_Sensore == 109),]

coordinates(CL_ROV2_OK_32) <- ~ E + N
proj4string(CL_ROV2_OK_32) <-CRS("+proj=utm +zone=32 ellps=WGS84")
Easting_index <- seq(1,length(coordinates(CL_ROV2_OK_32))/2,1)
Northing_index <-seq(length(coordinates(CL_ROV2_OK_32  ))/2+1,length(coordinates(CL_ROV2_OK_32)),1)
CL_ROV2_OK_32$Northing <- coordinates(CL_ROV2_OK_32)[Northing_index]
CL_ROV2_OK_32$Easting <- coordinates(CL_ROV2_OK_32)[Easting_index]

# ROV2_diff_solution_h      <- sqrt((CL_ROV2_OK_32$Easting-mean(CL_ROV2_OK_32$Easting[1:24],na.rm = T))^2
                                  # +(CL_ROV2_OK_32$Northing-mean(CL_ROV2_OK_32$Northing[1:24],na.rm = T))^2) 
# CL_ROV2_OK_84 <- spTransform(CL_ROV2_OK_32,CRS("+init=epsg:4326"))

nas <- which(is.na(hourly$Hourly) == T)



ifelse(length(nas)== 0, 
       hourly <- hourly ,
       hourly <- hourly[-nas,]);

coordinates(hourly) <- ~ lon + lat            ##assing coordinates
proj4string(hourly) <-CRS("+init=epsg:4326")  ##define coordinate Reference System

hourly_32 <- spTransform(hourly, CRS("+proj=utm +zone=32 ellps=WGS84")) ;  #rm(hourly)
Easting_index <- seq(1,length(coordinates(hourly_32))/2,1)
Northing_index <-seq(length(coordinates(hourly_32))/2+1,length(coordinates(hourly_32)),1)
hourly_32$Northing <- coordinates(hourly_32)[Northing_index]
hourly_32$Easting <- coordinates(hourly_32)[Easting_index]


# +unit=meters"))


# ifelse(length(nas) == 0,
diff_solution_h      <- sqrt((hourly_32$Easting-mean(hourly_32$Easting[1:24],na.rm = T))^2
                             +(hourly_32$Northing-mean(hourly_32$Northing[1:24],na.rm = T))^2)               #no NAS

#allineo lo zero dei GPS
CL_ROV1 %>%  arrange(Data) -> CL_ROV1
CL_ROV1_OK_32$BaseLine <- (CL_ROV1_OK_32$BaseLine- CL_ROV1_OK_32$BaseLine[1])+ sum(ROV1$soglia_spost_5[1:10])
CL_ROV2 %>%  dplyr::arrange(Data) -> CL_ROV2
CL_ROV2_OK_32$BaseLine <- (CL_ROV2_OK_32$BaseLine- CL_ROV2_OK_32$BaseLine[1])+ sum(ROV2$soglia_spost_5[1:26])
diff_solution_h <- diff_solution_h + sum(ROV3$soglia_spost_5[1:25])
hourly_32$plan_displ <- diff_solution_h

CL_ROV1$BaseLine <- (CL_ROV1$BaseLine- CL_ROV1$BaseLine[1])+ sum(ROV1$soglia_spost_5[1:10])
CL_ROV2$BaseLine <- (CL_ROV2$BaseLine- CL_ROV2$BaseLine[1])+ sum(ROV2$soglia_spost_5[1:26])


load("V:\\GIS-Globale-WMS/Ca_Lita_GIS/CL_GPS-Permanente/2016_marzo_dati_calita1/CL1_ROV1")
load("V:\\GIS-Globale-WMS/Ca_Lita_GIS/CL_GPS-Permanente/2016_marzo_dati_calita1/CL1_ROV2")
load("V:\\GIS-Globale-WMS/Ca_Lita_GIS/CL_GPS-Permanente/2016_marzo_dati_calita1/CL1_ROV3")

# par(new=F)
library(randomcoloR)
nColor <- 10
myColor <- randomcoloR::distinctColorPalette(k = 40)

par(mfrow = c(1,1))
plot(ROV1$dates,cumsum(ROV1[,6]),type='l',lty=1, ylim = c(0,350),col=myColor[5],
     xlab= 'Date', ylab= 'Cumulative displ. (m)',main='Rover 1') ##risultato NCC spost fino 5 metri
abline(v= ROV1$dates,col='grey')
for (i in c(1,2,3,4,6,7,8,9,10)) {
  lines(ROV1$dates,cumsum(ROV1[,i+1]),type='l',
        # ylim = c(0,300),
        col=myColor[i] 
        # col='gray'
        )
  par(new=TRUE)
}
lines(as.Date(CL_ROV1$Data),CL_ROV1$BaseLine) ##GPS
# lines(ROV1$dates,cumsum(ROV1[,6]),type='l',lty=2)##risultato NCC spost fino 5 metri
# lines(ROV1$dates,cumsum(ROV1$soglia_spost_10))
# lines(ROV1$dates,cumsum(ROV1$soglia_spost_1))
legend("topleft",legend = paste0("Threshold ",1:10,'m'),col = myColor,lty = rep(1,10))

lines(as.Date(CL1_ROV1$Data),CL1_ROV1$Baseline_diff,col="black")

# par(new=F)
plot(ROV2$dates,cumsum(ROV2[,6]),type='l',lty=1, ylim = c(0,350),col=myColor[5],
     xlab= 'Date', ylab= 'Cumulative displ. (m)',main='Rover 2') ##risultato NCC spost fino 5 metri
abline(v=ROV2$dates,col='grey')
for (i in c(1,2,3,4,6,7,8,9,10)) {
  lines(ROV2$dates,cumsum(ROV2[,i+1]),type='l', 
        # ylim = c(0,300),
        col=myColor[i])
  # col='gray')
  par(new=TRUE)
}
lines(as.Date(CL_ROV2$Data),CL_ROV2$BaseLine,col='black')  ##GPS
# lines(ROV2$dates,cumsum(ROV2[,6]),type='l',lty=2)##risultato NCC spost fino 5 metri
# lines(ROV2$dates,cumsum(ROV2$soglia_spost_10))
# lines(ROV2$dates,cumsum(ROV2$soglia_spost_1))

lines(as.Date(CL1_ROV2$Data),CL1_ROV2$Baseline_diff,col="black")
legend("topleft",legend = paste0("Threshold ",1:10,'m'),col = myColor,lty = rep(1,10))

# lines(as.Date(CL_ROV2_SysAny$Data),CL_ROV2_SysAny$BaseLine-CL_ROV2_SysAny$BaseLine[1],col="red")

# par(new=F)
plot(ROV3$dates,cumsum(ROV3[,6]),type='l', lty=1,ylim = c(0,350),col=myColor[5],
     xlab= 'Date', ylab= 'Cumulative displ. (m)',main='Rover 3')
for (i in c(1,2,3,4,6,7,8,9,10)) {
  lines(ROV3$dates,cumsum(ROV3[,i+1]),type='l', ylim = c(0,300),col=myColor[i])
  par(new=TRUE)
}
lines(as.Date(hourly_32$Hourly),diff_solution_h,col='black') ##GPS
# lines(ROV3$dates,cumsum(ROV3[,6]),type='l', lty=2)##risultato NCC spost fino 5 metri
# lines(ROV3$dates,cumsum(ROV3$soglia_spost_10))
# lines(ROV3$dates,cumsum(ROV3$soglia_spost_1))

lines(as.Date(CL1_ROV3$Data),CL1_ROV3$Baseline_diff+ROV3$soglia_spost_5[2],col="black")
abline(v=ROV1$dates,col='grey')

nomi_soglie <- c(paste0("thr.0",(1:9),'m'),"thr.10m")

# ROV1
k=1

a <- as.data.frame(ROV1$dates)
a$tipo_soglia <- rep(nomi_soglie[k],(nrow(a)))
a$disp <- ROV1[,k+1]
 Rov1_grp_barplot <- a
  
  for (i in 2:10) {
    a <- as.data.frame(ROV1$dates)
    a$tipo_soglia <- rep(nomi_soglie[i],(nrow(a)))
    a$disp <- ROV1[,i+1]
    Rov1_grp_barplot <- rbind(Rov1_grp_barplot,a)
  }

colnames(Rov1_grp_barplot)[1] <- "dates"
Rov1_grp_barplot$year <- lubridate::year(Rov1_grp_barplot$dates)
Rov1_grp_barplot$jd <- lubridate::yday(Rov1_grp_barplot$dates)

# ROV2
i=1
a <- as.data.frame(ROV2$dates)
a$tipo_soglia <- rep(nomi_soglie[i],(nrow(a)))
a$disp <- ROV2[,i+1]
Rov2_grp_barplot <- a

for (i in 2:10) {
  a <- as.data.frame(ROV2$dates)
  a$tipo_soglia <- rep(nomi_soglie[i],(nrow(a)))
  a$disp <- ROV2[,i+1]
  Rov2_grp_barplot <- rbind(Rov2_grp_barplot,a)
}
colnames(Rov2_grp_barplot)[1] <- "dates"
Rov2_grp_barplot$year <- lubridate::year(Rov2_grp_barplot$dates)
Rov2_grp_barplot$jd <- lubridate::yday(Rov2_grp_barplot$dates)

# ROV3
i=1
a <- as.data.frame(ROV3$dates)
a$tipo_soglia <- rep(nomi_soglie[i],(nrow(a)))
a$disp <- ROV3[,i+1]
Rov3_grp_barplot <- a

for (i in 2:10) {
  a <- as.data.frame(ROV3$dates)
  a$tipo_soglia <- rep(nomi_soglie[i],(nrow(a)))
  a$disp <- ROV3[,i+1]
  Rov3_grp_barplot <- rbind(Rov3_grp_barplot,a)
}
colnames(Rov3_grp_barplot)[1] <- "dates"
Rov3_grp_barplot$year <- lubridate::year(Rov3_grp_barplot$dates)
Rov3_grp_barplot$jd <- lubridate::yday(Rov3_grp_barplot$dates)


##creo dataframe con dati gps su base giornaliera con stesse date dei risultati NCC##
CL_ROV1_OK_32_d <- as.data.frame(CL_ROV1_OK_32)
polate_R1_2 <- approxfun(x=CL_ROV1_OK_32_d$Data,y=CL_ROV1_OK_32_d$BaseLine)
polate_R1_1 <- approxfun(x=CL1_ROV1$Data,y=CL1_ROV1$Baseline_diff)

R1_51_2 <- polate_R1_2(as.POSIXct(ROV1$dates)); R1_51_2[2:length(R1_51_2)] <- diff.Date(R1_51_2)
# R1_51[is.na(R1_51)] <- 0;
as.data.frame(R1_51_2) ->R1_51_2; R1_51_2$dates <- ROV1$dates; colnames(R1_51_2) <- c("disp","dates"); R1_51_2$tipo_soglia <- rep("GNSS",nrow(R1_51_2))

R1_51_1 <- polate_R1_1(as.POSIXct(ROV1$dates)); R1_51_1[2:length(R1_51_1)] <- diff.Date(R1_51_1)
# R1_51[is.na(R1_51)] <- 0;
as.data.frame(R1_51_1) ->R1_51_1; R1_51_1$dates <- ROV1$dates; colnames(R1_51_1) <- c("disp","dates"); R1_51_1$tipo_soglia <- rep("GNSS",nrow(R1_51_1))

R1_51 <- R1_51_2; R1_51[4,1] <- R1_51_1[4,1]
R1_51$year <- lubridate::year(R1_51$dates)
R1_51$jd <- lubridate::yday(R1_51$dates)
# R1_51$disp <- round(R1_51$disp,1) 
# R1_51$disp[which(R1_51$disp < 1)] <- NA
  


Rov1_grp_barplot <- rbind(Rov1_grp_barplot,R1_51)


CL_ROV2_OK_32_d <- as.data.frame(CL_ROV2_OK_32)
polate_R2_2 <- approxfun(x=CL_ROV2_OK_32_d$Data,y=CL_ROV2_OK_32_d$BaseLine)
polate_R2_1 <- approxfun(x=CL1_ROV2$Data,y=CL1_ROV2$Baseline_diff)

R2_51_2 <- polate_R2_2(as.POSIXct(ROV2$dates)); R2_51_2[2:length(R2_51_2)] <- diff.Date(R2_51_2)
# R2_51[is.na(R2_51)] <- 0;
as.data.frame(R2_51_2) ->R2_51_2; R2_51_2$dates <- ROV2$dates; colnames(R2_51_2) <- c("disp","dates"); R2_51_2$tipo_soglia <- rep("GNSS",nrow(R2_51_2))

R2_51_1 <- polate_R2_1(as.POSIXct(ROV2$dates)); R2_51_1[2:length(R2_51_1)] <- diff.Date(R2_51_1)
# R2_51[is.na(R2_51)] <- 0;
as.data.frame(R2_51_1) ->R2_51_1; R2_51_1$dates <- ROV2$dates; colnames(R2_51_1) <- c("disp","dates"); R2_51_1$tipo_soglia <- rep("GNSS",nrow(R2_51_1))

R2_51 <- R2_51_2; R2_51[4,1] <- R2_51_1[4,1]
# R2_51[39,1] <- abs(R2_51[39,1])
R2_51[39,1] <- NA
R2_51$year <- lubridate::year(R2_51$dates)
R2_51$jd <- lubridate::yday(R2_51$dates)
# R2_51$disp <- round(R2_51$disp,1) 
# R2_51$disp[which(R2_51$disp < 1)] <- NA


Rov2_grp_barplot <- rbind(Rov2_grp_barplot,R2_51)

hourly_32 <- as.data.frame(hourly_32)
polate_R3_2 <- approxfun(x=hourly_32$Hourly,y=diff_solution_h)
polate_R3_1 <- approxfun(x=CL1_ROV3$Data,y=CL1_ROV3$Baseline_diff)

R3_51_2 <- polate_R3_2(as.POSIXct(ROV3$dates)); R3_51_2[2:length(R3_51_2)] <- diff.Date(R3_51_2)
# R3_51[is.na(R3_51)] <- 0;
as.data.frame(R3_51_2) ->R3_51_2; R3_51_2$dates <- ROV3$dates; colnames(R3_51_2) <- c("disp","dates"); R3_51_2$tipo_soglia <- rep("GNSS",nrow(R3_51_2))

R3_51_1 <- polate_R3_1(as.POSIXct(ROV3$dates)); R3_51_1[2:length(R3_51_1)] <- diff.Date(R3_51_1)
# R3_51[is.na(R3_51)] <- 0;
as.data.frame(R3_51_1) ->R3_51_1; R3_51_1$dates <- ROV3$dates; colnames(R3_51_1) <- c("disp","dates"); R3_51_1$tipo_soglia <- rep("GNSS",nrow(R3_51_1))

R3_51 <- R3_51_2; R3_51[3:4,1] <- R3_51_1[3:4,1]
R3_51$year <- lubridate::year(R3_51$dates)
R3_51$jd <- lubridate::yday(R3_51$dates)
# R3_51$disp <- round(R3_51$disp,1) 
# R3_51$disp[which(R3_51$disp < 1)] <- NA

Rov3_grp_barplot <- rbind(Rov3_grp_barplot,R3_51)


library(ggplot2)
Rov1_grp_barplot %>% 
  ggplot(aes(fill=tipo_soglia,y=disp,x=jd))+ theme_bw()+
  geom_vline(xintercept = c(round(seq(1,365, by = 30.4166),0),365),color= 'black')+
  # scale_color_brewer(palette= 'Set1')+
    geom_bar(position="dodge", stat="identity",width = 10) +
  # geom_line(aes(color=tipo_soglia))+
  # geom_vline(xintercept = Rov1_grp_barplot$dates,color= 'grey')+
    # geom_point(aes( shape= tipo_soglia,color= tipo_soglia),size=2.5 )+
    # scale_shape_manual(values=c(8,0,2,5))+
    # scale_color_manual(values = c('black','blue','#c4132b','darkgreen'))+
  scale_x_continuous(breaks = c(round(seq(1,365, by = 30.4),0),365),
                     labels = c('','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec')) +
  xlab("")+ylab('Displacement (m)')+  
  ggtitle('ROV1')+
    facet_grid(year ~ .)

 Rov2_grp_barplot %>% 
  ggplot(aes(fill=tipo_soglia,y=disp,x=jd))+ theme_bw()+
   geom_vline(xintercept = c(round(seq(1,365, by = 30.4),0),365),color= 'black')+
       geom_bar(position="dodge", stat="identity",width = 10) +
   # geom_point(aes( shape= tipo_soglia,color= tipo_soglia),size=2.5 )+
   # scale_shape_manual(values=c(8,0,2,5))+
   # scale_color_manual(values = c('black','blue','#c4132b','darkgreen'))+
   scale_x_continuous(breaks = c(round(seq(1,365, by = 30.4),0),365),
                      labels = c('','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec')) +
   xlab("")+ylab('Displacement (m)')+  
  ggtitle('ROV2')+
   facet_grid(year ~ .)

Rov3_grp_barplot %>% 
  ggplot(aes(fill=tipo_soglia,y=disp,x=jd))+ theme_bw()+
  geom_vline(xintercept = c(round(seq(1,365, by = 30.4),0),365),color= 'black')+
    geom_bar(position="dodge", stat="identity",width = 10) +
  # geom_point(aes( shape= tipo_soglia,color= tipo_soglia),size=2.5 )+
  # scale_shape_manual(values=c(8,0,2,5))+
  # scale_color_manual(values = c('black','blue','#c4132b','darkgreen'))+
  scale_x_continuous(breaks = c(round(seq(1,365, by = 30.4),0),365),
                     labels = c('','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec')) +
  xlab("")+ylab('Displacement (m)')+
  ggtitle('ROV3')+
  facet_grid(year ~ .)


####Analisi dell'errore####
##ROV1
for (i in 1:length(nomi_soglie)) {
  a <- abs((dplyr::select(dplyr::filter(Rov1_grp_barplot,tipo_soglia == nomi_soglie[i] ),disp) -
              dplyr::select(dplyr::filter(Rov1_grp_barplot,tipo_soglia == "GNSS" ),disp))*100/
             dplyr::select(dplyr::filter(Rov1_grp_barplot,tipo_soglia == "GNSS"),disp)
          )
  assign(paste0("rel_err0",i),a)
}

# abs((dplyr::select(dplyr::filter(Rov1_grp_barplot,tipo_soglia == "thr.01m"),disp) -
#    dplyr::select(dplyr::filter(Rov1_grp_barplot,tipo_soglia == "GNSS"),disp))*100/
#             dplyr::select(dplyr::filter(Rov1_grp_barplot,tipo_soglia == "GNSS"),disp)
#   )-> rel_err01
# abs((dplyr::select(dplyr::filter(Rov1_grp_barplot,tipo_soglia == "thr.02m"),disp) -
#        dplyr::select(dplyr::filter(Rov1_grp_barplot,tipo_soglia == "GNSS"),disp))*100/
#       dplyr::select(dplyr::filter(Rov1_grp_barplot,tipo_soglia == "GNSS"),disp)
# )-> rel_err02
# abs((dplyr::select(dplyr::filter(Rov1_grp_barplot,tipo_soglia == "thr.05m"),disp) -
#     dplyr::select(dplyr::filter(Rov1_grp_barplot,tipo_soglia == "GNSS"),disp))*100/
#       dplyr::select(dplyr::filter(Rov1_grp_barplot,tipo_soglia == "GNSS"),disp)
#     ) -> rel_err05
# abs((dplyr::select(dplyr::filter(Rov1_grp_barplot,tipo_soglia == "thr.10m"),disp) -
#        dplyr::select(dplyr::filter(Rov1_grp_barplot,tipo_soglia == "GNSS"),disp))*100/
#       dplyr::select(dplyr::filter(Rov1_grp_barplot,tipo_soglia == "GNSS"),disp)
#     ) -> rel_err10
Rov1_grp_barplot$rel_err <- c(rel_err01$disp,rel_err02$disp,rel_err03$disp,rel_err04$disp,
                              rel_err05$disp,rel_err06$disp,rel_err07$disp,rel_err08$disp,
                              rel_err09$disp,rel_err010$disp,rep(NA,51))
Rov1_grp_barplot$nome_rov <- rep("ROV1",51*11)


ROV1_rel_err <- Rov1_grp_barplot %>% dplyr::filter(!tipo_soglia == "GNSS") 
ROV1_rel_err$dipl_GNSS <- rep(R1_51$disp,10)
ROV1_rel_err %>%
  # dplyr::filter(disp >=1) %>%
  dplyr::mutate(rel_err = (abs(disp-dipl_GNSS)/dipl_GNSS)*100) ->ROV1_rel_err

##ROV2
for (i in 1:length(nomi_soglie)) {
  a <- abs((dplyr::select(dplyr::filter(Rov2_grp_barplot,tipo_soglia == nomi_soglie[i] ),disp) -
              dplyr::select(dplyr::filter(Rov2_grp_barplot,tipo_soglia == "GNSS" ),disp))*100/
             dplyr::select(dplyr::filter(Rov2_grp_barplot,tipo_soglia == "GNSS"),disp)
  )
  assign(paste0("rel_err0",i),a)
}


# abs((dplyr::select(dplyr::filter(Rov2_grp_barplot,tipo_soglia == "GNSS"),disp) - 
#        dplyr::select(dplyr::filter(Rov2_grp_barplot,tipo_soglia == "thr.01m"),disp))*100/
#       dplyr::select(dplyr::filter(Rov2_grp_barplot,tipo_soglia == "GNSS"),disp) 
#     )-> rel_err01
# abs((dplyr::select(dplyr::filter(Rov2_grp_barplot,tipo_soglia == "GNSS"),disp) -
#        dplyr::select(dplyr::filter(Rov2_grp_barplot,tipo_soglia == "thr.05m"),disp))*100/
#       dplyr::select(dplyr::filter(Rov2_grp_barplot,tipo_soglia == "GNSS"),disp)
#     ) -> rel_err05
# abs((dplyr::select(dplyr::filter(Rov2_grp_barplot,tipo_soglia == "GNSS"),disp) -
#        dplyr::select(dplyr::filter(Rov2_grp_barplot,tipo_soglia == "thr.10m"),disp))*100/
#       dplyr::select(dplyr::filter(Rov2_grp_barplot,tipo_soglia == "GNSS"),disp)
#     ) -> rel_err10
Rov2_grp_barplot$rel_err <-  c(rel_err01$disp,rel_err02$disp,rel_err03$disp,rel_err04$disp,
                               rel_err05$disp,rel_err06$disp,rel_err07$disp,rel_err08$disp,
                               rel_err09$disp,rel_err010$disp,rep(NA,51))
Rov2_grp_barplot$nome_rov <- rep("ROV2",51*11)


ROV2_rel_err <- Rov2_grp_barplot %>% dplyr::filter(!tipo_soglia == "GNSS") 
ROV2_rel_err$dipl_GNSS <- rep(R2_51$disp,10)
ROV2_rel_err %>% 
  # dplyr::filter(disp >=1) %>%
  dplyr::mutate(rel_err = (abs(disp-dipl_GNSS)/dipl_GNSS)*100) ->ROV2_rel_err

# ROV3
for (i in 1:length(nomi_soglie)) {
  a <- abs((dplyr::select(dplyr::filter(Rov3_grp_barplot,tipo_soglia == nomi_soglie[i] ),disp) -
              dplyr::select(dplyr::filter(Rov3_grp_barplot,tipo_soglia == "GNSS" ),disp))*100/
             dplyr::select(dplyr::filter(Rov3_grp_barplot,tipo_soglia == "GNSS"),disp)
  )
  assign(paste0("rel_err0",i),a)
}


# abs((dplyr::select(dplyr::filter(Rov3_grp_barplot,tipo_soglia == "GNSS"),disp) - 
#        dplyr::select(dplyr::filter(Rov3_grp_barplot,tipo_soglia == "thr.01m"),disp))*100/
#       dplyr::select(dplyr::filter(Rov3_grp_barplot,tipo_soglia == "GNSS"),disp) 
#     )-> rel_err01
# abs((dplyr::select(dplyr::filter(Rov3_grp_barplot,tipo_soglia == "GNSS"),disp) -
#        dplyr::select(dplyr::filter(Rov3_grp_barplot,tipo_soglia == "thr.05m"),disp))*100/
#       dplyr::select(dplyr::filter(Rov3_grp_barplot,tipo_soglia == "GNSS"),disp)
#     ) -> rel_err05
# abs((dplyr::select(dplyr::filter(Rov3_grp_barplot,tipo_soglia == "GNSS"),disp) -
#        dplyr::select(dplyr::filter(Rov3_grp_barplot,tipo_soglia == "thr.10m"),disp))*100/
#       dplyr::select(dplyr::filter(Rov3_grp_barplot,tipo_soglia == "GNSS"),disp)
#     ) -> rel_err10
Rov3_grp_barplot$rel_err <-  c(rel_err01$disp,rel_err02$disp,rel_err03$disp,rel_err04$disp,
                               rel_err05$disp,rel_err06$disp,rel_err07$disp,rel_err08$disp,
                               rel_err09$disp,rel_err010$disp,rep(NA,51))
Rov3_grp_barplot$nome_rov <- rep("ROV3",51*11)


ROV3_rel_err <- Rov3_grp_barplot %>% dplyr::filter(!tipo_soglia == "GNSS") 
ROV3_rel_err$dipl_GNSS <- rep(R3_51$disp,10)
ROV3_rel_err %>%
  # dplyr::filter(disp >=1) %>% 
  dplyr::mutate(rel_err = (abs(disp-dipl_GNSS)/dipl_GNSS)*100) ->ROV3_rel_err

errori_GNSS_CIAS <- rbind(ROV3_rel_err,ROV2_rel_err,ROV1_rel_err)

fun.1 <- function(x) (1/(x)^2)

my.formula_asint <- y  ~ 1/log10(x)
errori_GNSS_CIAS %>% 
  dplyr::filter(dipl_GNSS >.1) %>%
  dplyr::filter(!rel_err == 100) %>%
  ggplot(aes(y= (abs(rel_err)),x=dipl_GNSS)) +theme_bw()+
  geom_point(
    # aes( shape= tipo_soglia,color= nome_rov),size=2.5
    ) +
  xlab("GNSS displ. (m)")+ylab('Relative error %')+
   geom_hline(yintercept=0,linetype= 'solid',color="darkgray")+
  geom_hline(yintercept=100,linetype= 'dashed')+
  geom_vline(xintercept=0,linetype= 'solid',color="darkgray")+
  geom_vline(xintercept=2,linetype= 'solid',color="black")+
  geom_vline(xintercept=7,linetype= 'solid')+
  geom_hline(yintercept=15,linetype= 'dashed')+
    # ylim(c(0,1)) +
geom_smooth(method="auto", se=TRUE, #fill=NA,
             formula=y ~ 1/log10(x),colour="red")
  # stat_poly_eq(formula = my.formula,aes(label = paste(..eq.label.., ..rr.label.., sep = "~~~")), parse = TRUE)
  # stat_function(fun = fun.1) + xlim(-10,60)
errori_GNSS_CIAS %>% 
  dplyr::filter(dipl_GNSS >1) %>% 
  # dplyr::filter(tipo_soglia== nomi_soglie[i]) %>% 
  dplyr::filter(!rel_err == 100)  %>% 
  ggplot( aes(tipo_soglia, rel_err,ylim(0,100),ylab ='% Error')) + #geom_boxplot(outlier.shape = NA) +geom_hline(yintercept = 100)
  geom_boxplot(outlier.shape = NA) -> p0

statistica <- as.data.frame(matrix(NA,nrow = 10,ncol = 2));colnames(statistica) <- c('median_err_rel',"R2_lm")
for (i in 1:10) {
  errori_GNSS_CIAS %>% 
    dplyr::filter(dipl_GNSS >1) %>%
   dplyr::filter(tipo_soglia== nomi_soglie[i]) %>% 
    dplyr::filter(!rel_err == 100)  -> stats
  boxplot.stats(stats$rel_err)$stats[3] -> statistica[i,1]
}

# compute lower and upper whiskers
errori_GNSS_CIAS %>% 
  dplyr::filter(dipl_GNSS >1) %>%
  # dplyr::filter(tipo_soglia== nomi_soglie[i]) %>% 
  dplyr::filter(!rel_err == 100)  -> stats
 boxplot.stats(stats$rel_err)$stats[c(1, 5)] -> ylim1

# scale y limits based on ylim1
p1 <- p0 + 
  coord_cartesian(
  ylim = c(0,100)) +
  # ylim = c(ylim1*1.05)) +
  labs(y= "Error %",x= "Threshold (m)")
p1

###scatter plot####
my.formula <- y ~ x
i=1
for (i in 1:10) {
  errori_GNSS_CIAS %>% 
  # dplyr::filter(dipl_GNSS >5 & dipl_GNSS < 25) %>%
    dplyr::filter(dipl_GNSS >1) %>% 
  dplyr::filter(!rel_err == 1) %>%
  dplyr::filter(tipo_soglia== nomi_soglie[i])%>%
  ggplot(aes(y= disp,x=dipl_GNSS,)) +theme_bw()+
    geom_point(
    # aes( shape= tipo_soglia,color= nome_rov),size=2.5
    ) + 
  geom_smooth(method= "lm",size = .2, color = 'grey',se=TRUE) +xlab("GNSS displ. (m)")+ylab('NCC displ. (m)')+
  ggtitle(nomi_soglie[i]) + geom_abline(linetype='dashed')+ xlim(c(0,50)) + ylim(c(0,50))+ coord_fixed(ratio = 1)+ 
    stat_poly_eq(formula = my.formula,aes(label = paste(..eq.label.., ..rr.label.., sep = "~~~")), parse = TRUE) 

  }


# #### bland graph#### 
#  blandr::blandr.draw(R1_51$disp,(ROV1$soglia_spost_10))
