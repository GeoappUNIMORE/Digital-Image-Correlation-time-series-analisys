# ### GPS###
library('raster')
library('rgdal')
library('plotrix')
library('dplyr')

calita_perimeter <- readOGR(dsn="C:/RICERCA/calita", layer= "calita_perimeter")
GPS_perm <- readOGR(dsn="C:/RICERCA/calita", layer = "rover_calita_utm32")
# plot(calita_perimeter)
# points(GPS_perm,pch=19,col='blue')

basemap <- raster("C:/RICERCA/CIAS_CORRELATION-IMAGE-ANALYSIS/calita_b04/da_processare/T32TPQ_A008528_20181024T102428_B04.jp2")

folders <- list.dirs(full.names = F)
folders <-  folders[grep('_20',folders)]
folders <- folders[-grep('/',folders)]; folders <- folders[c(1:9,11,13,15,17:20,22,25,27,29,31,33,36,40,42,44,48,51,54,57,60,63:73,75:77,79,81:84)]

dates <- vector(length = length(folders)+1)

i=1

for (i in 1 : length(folders) ){
  dates [i] <- paste0(substr(folders[i],start = 1,stop = 4),'/',
                      substr(folders[i],start = 5,stop = 6),'/',
                      substr(folders[i],start = 7,stop = 8)
  )
  }
dates[i+1] <- paste0(substr(folders[i],start = 1+9,stop = 4+9),'/',
                     substr(folders[i],start = 5+9,stop = 6+9),'/',
                     substr(folders[i],start = 7+9,stop = 8+9)
)
dates <- as.Date(dates)

soglia <- 1:10
# k=2
for (k in 1:length(soglia)) {
 
 
disp <- data.frame(matrix(ncol = 5, nrow = length(dates))); colnames(disp) <- c("Date",rev(as.character(GPS_perm$Punto)),'delta_T')
  

disp$Date <- dates
disp$delta_T[2:nrow(disp)] <- diff(disp$Date)

disp[1,2:4] <- rep(0,3)

pal <- colorRampPalette(c("green",'yellow',"red"),alpha = .5)
corr_th <- 0


# i=4
  for (i in 1:length(folders)) {
    # for (i in 1:4) {
    print(i)
    data <- (read.csv(paste0(folders[i],"/NCC_10_15_10.txt")))
    data_50 <- (read.csv(paste0(folders[i],"/NCC_10_15_50.txt")))
    colnames(data)[5] <- "displ"
    
    
    data_coer <- dplyr::filter(data, max_corrcoeff >= corr_th )
    data_coer_50 <- dplyr::filter(data_50, max_corrcoeff >= corr_th )
    
    z_max <- 60
    
    r_50 <- rasterFromXYZ(data_coer_50); crs(r_50) <- CRS("+init=epsg:32632")
    r_50 <- mask(r_50,calita_perimeter[2:4,])
    # r_50 <- rasterToPolygons(r_50)
    r_50$X <- coordinates(r_50)[,1]
    r_50$Y <- coordinates(r_50)[,2]
    
    r <- rasterFromXYZ(data_coer)
    crs(r) <- CRS("+init=epsg:32632")
    r <- mask(r,calita_perimeter[2:4,])
    colori <- colorRampPalette(c('green','yellow','red'))
    # q_98 <- quantile(mask(r$displ,calita_perimeter[which(calita_perimeter$Id == 1),]),probs = 0.98)
    q_99 <- quantile(r_50$length,probs = 0.99)
    
    while(q_99 < 10) {
      q_99 <- 10
    }
    
    ##### aggiungere filtro direzione, no movimenti verso monte ##### 
    data_coer %>% dplyr::filter(direction >= 45 & direction <= 225) -> data_coer
    # dplyr::filter(data_coer,data_coer$X < as.numeric(GPS_perm$Lat[1]+30) & data_coer$X > as.numeric(GPS_perm$Lat[1]-30) & data_coer$Y < as.numeric(GPS_perm$Long[1]+30) & data_coer$Y > as.numeric(GPS_perm$Long[1]-30))  -> disp_ROV3
  
   
   dplyr::filter(data_coer,data_coer$X < as.numeric(GPS_perm$Lat[1]+30) & data_coer$X > as.numeric(GPS_perm$Lat[1]-30) & data_coer$Y < as.numeric(GPS_perm$Long[1]+30) & data_coer$Y > as.numeric(GPS_perm$Long[1]-30)) -> disp_ROV3
   dplyr::filter(data_coer,data_coer$X < as.numeric(GPS_perm$Lat[2]+30) & data_coer$X > as.numeric(GPS_perm$Lat[2]-30) & data_coer$Y < as.numeric(GPS_perm$Long[2]+30) & data_coer$Y > as.numeric(GPS_perm$Long[2]-30)) -> disp_ROV2
   dplyr::filter(data_coer,data_coer$X < as.numeric(GPS_perm$Lat[3]+30) & data_coer$X > as.numeric(GPS_perm$Lat[3]-30) & data_coer$Y < as.numeric(GPS_perm$Long[3]+30) & data_coer$Y > as.numeric(GPS_perm$Long[3]-30)) -> disp_ROV1
   
   if (nrow(disp_ROV3)>1) {
     print('ok')
   } else{
     as.data.frame(matrix(0,ncol=1,nrow=1))-> disp_ROV3
     colnames(disp_ROV3) <- c('displ')
   }
  
   if (nrow(disp_ROV2)>1) {
     print('ok')
   } else{
     as.data.frame(matrix(0,ncol=1,nrow=1))-> disp_ROV2
     colnames(disp_ROV2) <- c('displ')
   }
  
   if (nrow(disp_ROV1)>1) {
     print('ok')
   } else{
     as.data.frame(matrix(0,ncol=1,nrow=1))-> disp_ROV1
     colnames(disp_ROV1) <- c('displ')
   }
   
  
   soglia_spost <- soglia[k]
  
   ifelse(round(median(disp_ROV3$displ,na.rm = T),1) <= soglia_spost,
          0 -> disp$ROV3[i+1],
          round(median(disp_ROV3$displ,na.rm = T),1) -> disp$ROV3[i+1])
  
  ifelse(round(median(disp_ROV2$displ,na.rm = T),1) <= soglia_spost,
         0 -> disp$ROV2[i+1],
         round(median(disp_ROV2$displ,na.rm = T),1) -> disp$ROV2[i+1])
  
  ifelse(round(median(disp_ROV1$displ,na.rm = T),1) <= soglia_spost,
         0 -> disp$ROV1[i+1],
         round(median(disp_ROV1$displ,na.rm = T),1) -> disp$ROV1[i+1])
  
  #
  }
assign(paste0("disp_",k),disp)
print(paste0("soglia spost = ",k))
save(list=paste0("disp_",1:10),
     file = paste0("C:/RICERCA/CIAS_CORRELATION-IMAGE-ANALYSIS/calita_b04/r/03_ts_spostamento/ts_spostamento_delta_",k))

}
ROV_names <- paste0("ROV",1:3)
  for (i in 1:3) {
    disp_tot <- as.data.frame( dates)
     for (j in 1:length(soglia)) {
     load(paste0("C:/RICERCA/CIAS_CORRELATION-IMAGE-ANALYSIS/calita_b04/r/03_ts_spostamento/ts_spostamento_delta_",soglia[j])) -> disp
       assign("d",get(paste0("disp_",j)))
       cbind(disp_tot,d[,(i+1)]) -> disp_tot
     colnames(disp_tot)[j+1] <- paste0("soglia_spost_",j)
   
     }
    assign(ROV_names[i],disp_tot)
    
    }

save(ROV1,ROV2,ROV3,file = "/RICERCA/CIAS_CORRELATION-IMAGE-ANALYSIS/calita_b04/r/03_ts_spostamento/03_ts_spostamento")
